const inputField = document.getElementById("guess")
const checkButton = document.getElementById("checkButton")
const message = document.getElementById("message")

// 正解の数をランダムに生成
const answer = Math.floor(Math.random() * 10) + 1
let attempts = 0

checkButton.addEventListener("click", function () {
    const guess = parseInt(inputField.value)

    if (isNaN(guess) || guess < 1 || 10 < guess) {
      message.innerHTML = "1から10の数を入力してね。"
    } else {
        attempts += 1

        if (guess === answer) {
            message.innerHTML = `正解！${attempts}回目で当たったよ！`
            checkButton.disabled = true
        } else if (guess < answer) {
            message.innerHTML = "もっと大きな数だよ。"
        } else {
            message.innerHTML = "もっと小さな数だよ。"
        }
    }
    inputField.focus()
})

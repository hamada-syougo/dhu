const FPS = 30 // ゲーム速度
const JUMP_HEIGHT = 100 // ジャンプの高さ
let score = 0
let isJumping = false

const character = document.getElementById('character')
const obstacle = document.getElementById('obstacle')

document.addEventListener('keydown', function (event) {
  if (event.code === 'Space' && !isJumping) {
    jump()
  }
})

// ジャンプする
function jump() {
  if (!isJumping) {
    isJumping = true
    let jumpCount = 0

    const jumpInterval = setInterval(function () {
      const characterTop = parseInt(
        getComputedStyle(character).getPropertyValue('bottom')
      )

      if (characterTop < JUMP_HEIGHT && jumpCount < 15) {
        // ジャンプの処理
        character.style.bottom = characterTop + 20 + 'px'
      } else {
        clearInterval(jumpInterval)

        // 落下処理
        let fallCount = 0
        const fallInterval = setInterval(function () {
          const characterTop = parseInt(
            getComputedStyle(character).getPropertyValue('bottom')
          )
          if (characterTop > 0 && fallCount < 15) {
            character.style.bottom = characterTop - 20 + 'px'
          } else {
            clearInterval(fallInterval)
            isJumping = false
          }
          fallCount++
        }, 1000 / FPS)
      }
      jumpCount++
    }, 1000 / FPS)
  }
}

function updateScore() {
  score += 1
  document.getElementById('score').innerHTML = `スコア: ${score}`
}

// 障害物を移動する
function moveObstacle() {
  // 障害の出現位置
  const OBSTACLE_START = 600
  let obstacleLeft = OBSTACLE_START
  const obstacleInterval = setInterval(function () {
    if (obstacleLeft < -60) {
      obstacleLeft = OBSTACLE_START
      updateScore()
    } else {
      obstacleLeft -= 10
      obstacle.style.left = obstacleLeft + 'px'
    }

  }, 1000 / FPS)
}

moveObstacle()
